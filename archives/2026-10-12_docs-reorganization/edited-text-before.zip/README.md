# H7MS-Core-A1

通用机器人实时控制核心。上位机使用树莓派等Linux计算平台；本板负责设备通信、带时间戳的采样、目标调度和故障处理，与具体机器人无绑定。

**当前方案：STM32H735VGH6（TFBGA100，0.8 mm）+ Direct SMPS。**阶段为引脚与外围规划，尚无正式EDA/PCB/固件或实测性能。

| 资源 | 规划 |
| --- | --- |
| 通信 | 3路独立原生FDCAN、USB FS Device、4组设备UART TX/RX/DIR、UART8与UART7辅助 |
| 感知/存储 | BMI088双CS/双IRQ，W25Q128JVPIQ 16MiB NOR，4-bit TF |
| 扩展 | 4路PWM、SPI3、I²C2、ADC、RGB/蜂鸣器及电源/故障信号 |
| 电源/恢复 | 5V→3.3V→Direct SMPS；BOOT0、NRST、SWD与电源测试点 |

外部总线物理层、执行器配电和独立禁止回路放在底板。75个信号焊盘、2个预留焊盘及23个电源/系统球位已形成100球连接表；前三路PWM共用TIM2周期。USB是12Mbit/s FS，W25Q128是Flash，不是RAM。

- [设计总结](docs/H7MS-Core-A1/总结分析报告.md)
- [最小系统具体接法](docs/H7MS-Core-A1/最小系统与外围规划.md)
- [引脚与接口规划](docs/H7MS-Core-A1/引脚规划.md)
- [外围器件选型](docs/H7MS-Core-A1/外围器件选型.md)
- [硬件架构](docs/H7MS-Core-A1/硬件架构.md) / [原理图输入状态](docs/H7MS-Core-A1/原理图/README.md)
- [按板名组织的资料总索引](docs/README.md)：DJI A、DJI C、达妙DM-MC02、D_MAIN_2558
- [项目待办](docs/项目管理/项目状态与待办.md) / [验证](docs/H7MS-Core-A1/验证/README.md)
- [整理与清理记录](docs/项目管理/文件整理记录.md) / [历史快照](archives/README.md)

版本：Docs v0.8.0，Pin Plan v0.8 draft，2026-10-11。下一步建立CubeMX时钟/DMA与正式EDA工程，完成电气、布线和并发验证。
