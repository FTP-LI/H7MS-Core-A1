# DJI RoboMaster C型控制板评估

日期：2026-09-15。**C型适合借鉴紧凑布局、基础设备通信和IMU分区；资源少于新H7平台，但整体职责清楚。**H7MS可以采用其模块组织思路，容量与总线能力应按新需求重算。

## 1. 证据与版本

资料来自[DJI官方产品页](https://www.robomaster.com/zh-CN/products/components/general/development-board-type-c)及官方CDN：

- [官方用户手册](../../../references/control-boards/2026-09-15/dji-type-c/user-manual-official.pdf)：21个PDF页面，2020年版。
- [官方原理图与位号图ZIP](../../../references/control-boards/2026-09-15/dji-type-c/schematic-and-layout-official.zip)：保留原始压缩文件及原始成员名对应表。
- [主板原理图](../../../references/control-boards/2026-09-15/dji-type-c/official-bundle-document-2.pdf)：7个PDF页面，页签2～8/8，Rev V1.0，图纸日期2019-12-05。
- [IMU FPC原理图](../../../references/control-boards/2026-09-15/dji-type-c/official-bundle-document-4.pdf)：1页，Rev V1.0；另保存主板和FPC位号图。

文件名映射、下载地址和哈希见[来源清单](../../../references/control-boards/2026-09-15/dji-type-c/source-index.json)。以下P1～P7均指主板PDF页面；FPC单独标识。已查看主板7页及FPC原理图，不包含PCB走线、固件审计或硬件试验。

## 2. 资源与电路观察

| 模块 | 观察结果 | 依据与边界 |
| --- | --- | --- |
| 主控 | STM32F407IGH6系列BGA封装；最高168 MHz、1 MB Flash、192 KB RAM及4 KB备份RAM | 主板P3～5；图中料号带TR包装后缀，不能替换为常见F407ZGT6并沿用封装 |
| CAN | 2路经典CAN，4个接插件，两路各2口 | 主板P3、P7；TJA1044GTK/3是物理层，控制器仍是F407经典CAN |
| PWM | 7路：TIM1 CH1～4、TIM8 CH1～3 | 主板P3、P7；共用两组定时器周期，须对频率组合做约束 |
| 通信与扩展 | UART1/6接口、USART3相关DBUS反相链路、Micro-USB、SPI2、I²C2、DCMI | 主板P3～5、P7；遥控接口与一般UART有电路/用途差异 |
| 惯性传感 | BMI088位于独立FPC小板；IST8310位于主板 | 主板P6和FPC P1；SPI、独立中断、专用电源及加热链路均可见 |
| 加热 | FPC上10只430Ω并联，MOSFET控制，有栅极下拉 | FPC P1；5V下理想满占空功率约0.58W，是电路计算，不是恒温性能测试 |
| 电源与调试 | 输入电源、核心电源和PWM电源支路、SWD、BOOT、复位 | 主板P1～3；厂商输入范围8～28V，各支路限值仍按手册及具体电路确认 |
| 外部存储/网络 | 本次主板与FPC图纸未见TF、QSPI NOR或以太网PHY | 不推断芯片不支持，也不推断其他产品修订相同 |

主控参数依据[ST F407IG](https://www.st.com/en/microcontrollers-microprocessors/stm32f407ig.html)。

## 3. 特别记录：电源框图不能代替详细电路

主板P1的电源树将`TJA1044GTK/3`画在类似5V产生3.3V的位置，容易被误读为稳压器。**TJA1044是CAN收发器；VIO是逻辑电源输入，不是3.3V电源输出。**详细CAN电路中VIO接3.3V，应依据管脚连接及[NXP TJA1044数据手册第7.4节](https://www.nxp.com/docs/en/data-sheet/TJA1044.pdf)理解。

这里记录的是文档框图表达问题，不能据此判定原板实物电源接错。对H7MS的要求是：电源树必须与稳压器、收发器、负载及网名一致，评审时逐个追溯到详细原理图；不要照抄框图作为电源设计依据。

## 4. 值得借鉴与局限

| 维度 | 评价 | H7MS采纳方式 |
| --- | --- | --- |
| 功能收敛 | 基础CAN、PWM、串口、IMU和调试组成紧凑控制板 | 首版先交付可验证的通信与控制，再加入可选扩展 |
| IMU机械/电气分区 | FPC单独承载BMI088与热源，主板提供接口 | 借鉴分区和测量噪声意识；是否采用FPC仍看振动、结构、连接可靠性和成本 |
| 接口密度 | 多种外设有清晰分组，小板也能覆盖机器人常用连接 | H7MS每组接口注明电压、复用、共用定时器及供电总预算 |
| 计算/存储 | F407资源需要较紧的RTOS、队列和算法预算 | 用其证明基础控制不必堆满功能；新平台保留H7存储/计算余量 |
| 总线 | 2路经典CAN，缺板载RS-485与网络PHY | 不按接插件数扩张能力；新底板按设备配置选择FD/RS-485 |
| 配电与安全 | 电源输出和控制信号存在，独立停止行为未由本次证据证明 | 逐路定义电源开关、硬件使能和故障传播，不能把普通输出口当作安全输出 |

磁力计附近的电流回路和安装环境、FPC振动与固定方式、加热的温度控制，以及电源噪声都需要PCB与实测支持。原理图中的电源树和支路电流标注也应与对应BOM/说明书交叉核对后使用。

## 5. 评价与验证重点

**评价：适合作为“紧凑基础控制板”的组织参考；不满足H7MS新增多协议、较大缓冲或CAN FD的需求本身。**优先借鉴接口分组、IMU独立区域和可调试性，保留H7MS自身电源/资源评审流程。

采用相关设计前，重点验证IMU温漂及振动、PWM共享定时器配置、CAN满载与总线故障、外设供电短路/瞬态对MCU的影响、复位与重新使能行为。所有结果需绑定具体板卡和固件版本。
