# 项目历史快照

当前设计入口在[docs](../docs/README.md)。历史文件用于追溯，不覆盖当前H735方案。

- [2026-09-15_board-research](2026-09-15_board-research/README.md)
- [2026-10-11_before-docs-v0.8.0](2026-10-11_before-docs-v0.8.0/README.md)
