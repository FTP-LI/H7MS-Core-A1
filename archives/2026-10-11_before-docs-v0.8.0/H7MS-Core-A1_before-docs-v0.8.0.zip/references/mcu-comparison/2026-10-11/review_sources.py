"""Rebuild the offline evidence index; never download or overwrite source PDFs."""
from pathlib import Path
import hashlib
import json
import pymupdf

ROOT = Path(__file__).resolve().parent
BASE = 'https://www.st.com/resource/en/'
SOURCES = [
    dict(id='S1', document='DS13313', revision='5', publication='2025-05',
         official_url=BASE+'datasheet/stm32h723vg.pdf', review_method='official-online-text',
         checked_sections=['Table 1', '3.1', '3.3', '3.5', '3.6', '3.34', '3.42', 'Tables 7/8', 'Tables 12/13']),
    dict(id='S2', document='DS12110', revision='11', publication='2026-01',
         official_url=BASE+'datasheet/stm32h743vi.pdf', review_method='official-online-text',
         checked_sections=['Table 2 and footnotes', '3.3', 'ADC and USB sections', 'Revision V electrical conditions']),
    dict(id='S3', document='RM0468', revision='3', publication='2021-12',
         official_url=BASE+'reference_manual/dm00603761.pdf', review_method='official-search-index-excerpt',
         checked_sections=['Table 8, printed page 141'],
         limitation='Only the relevant memory configuration table was read; complete PDF was unavailable.'),
    dict(id='S4', document='RM0433', revision='8', publication='2023-01',
         official_url=BASE+'reference_manual/rm0433-stm32h743-753-and-stm32h750-value-line-advanced-arm-based-32-bit-mcus-stmicroelectronics.pdf',
         review_method='local-manufacturer-pdf-from-third-party-mirror',
         download_url='https://hangpersonal.com/wp-content/uploads/2024/10/STM32H753xI-Reference-Manual.pdf',
         local_file='RM0433_H743.pdf',
         checked_sections=['56.1', '56.4.2', 'Printed pages 2459, 2464, 2473-2475', 'Figure 737 visually reviewed'],
         limitation='ST cover and revision checked; binary identity against the official server was not verified.'),
    dict(id='S5', document='AN4891', revision='7', publication='2025-07',
         official_url=BASE+'application_note/dm00306681.pdf', review_method='official-online-text',
         checked_sections=['2.5', 'Printed pages 19-23'],
         limitation='Family-level RAM tables do not override exact H723VG datasheet capacities.'),
    dict(id='S6', document='ES0491', revision='9', publication='2024-06',
         official_url=BASE+'errata_sheet/es0491-stm32h72xx73xx-device-errata-stmicroelectronics.pdf',
         review_method='official-online-text',
         checked_sections=['Revision identification and applicability tables', '2.21.5', '2.22', '2.23.1', '2.24 summary']),
    dict(id='S7', document='ES0392', revision='15', publication='2025-09',
         official_url=BASE+'errata_sheet/es0392-stm32h742xig-stm32h743xig-stm32h750xb-stm32h753xi-device-errata-stmicroelectronics.pdf',
         review_method='official-online-text',
         checked_sections=['Revision identification', 'Table 3', '2.22.6', '2.24', '2.25.3']),
]

def main():
    records = []
    for source in SOURCES:
        record = dict(source)
        record['local_pdf_archived'] = 'local_file' in record
        if record['local_pdf_archived']:
            path = ROOT / record['local_file']
            data = path.read_bytes()
            assert data.startswith(b'%PDF'), path
            with pymupdf.open(path) as pdf:
                assert 'RM0433 Rev 8' in pdf[0].get_text()
                record['pdf_pages'] = len(pdf)
            record['bytes'] = len(data)
            record['sha256'] = hashlib.sha256(data).hexdigest()
        records.append(record)
    index = dict(review_date='2026-10-11',
                 scope='Relevant chapters and errata; no hardware qualification or full-manual review.',
                 download_note='Direct ST PDF requests returned HTTP 567. Only S4 was archived locally, from the disclosed mirror. Other failed mirror attempts did not produce retained PDFs.',
                 sources=records)
    (ROOT/'source-index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print('Indexed 7 sources; verified 1 locally archived PDF. No downloads performed.')

if __name__ == '__main__':
    main()
