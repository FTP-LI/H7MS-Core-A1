# 达妙DM-MC02资料索引

采集日期：2026-09-15。厂商项目页链接的Gitee仓库资料；V1.0-240124图纸与2025年V1.1手册版本不同。

[独立评估](../../../../docs/reviews/2026-09-15/03_达妙DM-MC02评估.md) · [文件来源与SHA-256](source-index.json)

## 原始资料

| 文件 | 来源/性质 |
| --- | --- |
| [official-project-page.html](official-project-page.html) | [原始下载地址](https://oshwhub.com/dmbot/dm_mc02-h7-kai-fa-ban-pei-tao) |
| [repository-page.html](repository-page.html) | [原始下载地址](https://gitee.com/kit-miao/dm-mc02) |
| [schematic-v1.0-240124.pdf](schematic-v1.0-240124.pdf) | [原始下载地址](https://gitee.com/kit-miao/dm-mc02/raw/master/2D%E5%9B%BE%E7%BA%B8/%E5%8E%9F%E7%90%86%E5%9B%BE/CtrBoard-H7_V1.0-240124.pdf) |
| [user-manual-v1.1.pdf](user-manual-v1.1.pdf) | [原始下载地址](https://gitee.com/kit-miao/dm-mc02/raw/master/%E8%AF%B4%E6%98%8E%E4%B9%A6/%E8%BE%BE%E5%A6%99%E7%A7%91%E6%8A%80DM-MC-Board02%E7%94%B5%E6%9C%BA%E5%BC%80%E5%8F%91%E6%9D%BF%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E%E4%B9%A6V1.1.pdf) |

## 预览与阅读规则

预览和提取文本是本地生成的辅助材料。PDF原理图全部页面已渲染；用户手册仅渲染封面，但保存全文提取文本。DXF解析文字坐标并生成整页预览，部分原始符号文字重叠；精确连线以原文件和后续原生EDA/BOM复核为准。

- schematic-v1.0-240124：[首张预览](previews/schematic-v1.0-240124/page-01.png)、[全文提取](previews/schematic-v1.0-240124/extracted.txt)；其他页面在同目录按页码命名。
- user-manual-v1.1：[首张预览](previews/user-manual-v1.1/page-01.png)、[全文提取](previews/user-manual-v1.1/extracted.txt)；其他页面在同目录按页码命名。

原始PDF/DXF/ZIP保持下载或接收时字节，文件未因本次评估而修改。HTML只作来源快照，可能依赖网络脚本；不作为离线图纸或自动执行入口。第三方材料仍归原权利人，本次归档用于项目研究，不推定获得改版生产、商标或固件再分发许可。
